<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

$router->get('/', function () use ($router) {
    return $router->app->version();
});

$router->group(['prefix' => 'api/v1'], function () use ($router) {

    $router->group(['middleware' => 'auth'], function () use ($router) {

        //Dashboard
        $router->get('home',  ['uses' => 'DashboardController@index']);

        //campagne
        $router->post('create-campagne', ['uses' => 'CampagneController@create']);
        $router->get('campagne', ['uses' => 'CampagneController@list']);
        $router->put('update-campagne/{id}', ['uses' => 'CampagneController@update']);

        //contact
        $router->post('create-contact', ['uses' => 'ContactController@create']);
        $router->get('contact', ['uses' => 'ContactController@list']);
        $router->put('update-contact', ['uses' => 'ContactController@update']);

        //Groupe
        $router->post('create-groupe', ['uses' => 'GroupController@create']);
        $router->get('groupe', ['uses' => 'GroupController@list']);
        $router->put('update-groupe', ['uses' => 'GroupController@update']);

        //Contact_group
        $router->post('create-contact_group', ['uses' => 'GroupController@createContactGroup']);


        //mail
        $router->post('create-mail', ['uses' => 'MailController@create']);
        $router->get('mail', ['uses' => 'MailController@list']);
        $router->put('update-mail', ['uses' => 'MailController@update']);


        //model

        $router->post('create-model', ['uses' => 'ModelController@create']);
        $router->get('model', ['uses' => 'ModelController@list']);
        $router->put('update-model', ['uses' => 'ModelController@update']);

        //Authentification - logout
        $router->get('logout','AuthController@logout');

    });

    //Authentification
    $router->post('login','AuthController@login');

    //Organisation
    $router->get('show-organization/{id}', ['uses' => 'OrganizationController@show']);
    $router->post('update-user-organization', ['uses' => 'OrganizationController@updateUserOrg']);
    $router->get('all-user-organization', ['uses' => 'OrganizationController@allOrganizationsUser']);

});

