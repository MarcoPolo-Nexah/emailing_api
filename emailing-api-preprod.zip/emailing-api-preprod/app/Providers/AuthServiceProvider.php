<?php

namespace App\Providers;

use App\User;
use Illuminate\Support\ServiceProvider;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Boot the authentication services for the application.
     *
     * @return void
     */
    public function boot()
    {
        // Here you may define how you wish users to be authenticated for your Lumen
        // application. The callback which receives the incoming request instance
        // should return either a User instance or null. You're free to obtain
        // the User instance via an API token or any other method necessary.

        $this->app['auth']->viaRequest('api', function ($request) {
            if ($request->header('Authorization')) {

                $key = $request->header('Authorization');
                if (str_starts_with($key, 'Bearer ')) {
                    $accessToken = str_replace('Bearer ', '', $key);

                    $user['access_token'] = $accessToken;
                    $plainText = decrypter($accessToken);
                    $items = explode(";", $plainText);

                    $user['sso_user_id'] = $items[0]; //Item 0 is the userId
                    $user['org_id'] = $items[1]; //Item 1 is the orgId
                    $user['app_slug'] = $items[2]; //Item 2 is app slug

                    $roleText = $items[3]; //Item 3 is user roles in the App
                    $user['roles'] = explode("&", $roleText);

                    $user['jwt_token'] = $items[4]; //Item 4 is the jwtToken

                    return $user;
                }else{
                    return null;
                }
            }
        });
    }
}
