<?php


namespace App\Utils;


trait JResponse
{
    public function json($status, $message, $data = null){
        if ($data != null){
            $result = array('status' => $status, 'message' => $message, 'data' => $data);
        }else{
            $result = array('status' => $status, 'message' => $message);
        }
        return response()->json($result, 200);
    }
}
