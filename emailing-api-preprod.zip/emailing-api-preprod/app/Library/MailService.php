<?php
/**
 * Created by PhpStorm.
 * User: eddy
 * Date: 13/12/18
 * Time: 10:47
 */

namespace App\Library;

use App\Library\Repository\MailServiceInterface;

class MailService implements MailServiceInterface
{

}
