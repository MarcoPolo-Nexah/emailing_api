<?php


namespace App\Library;


use App\Library\Repository\SSOServiceInterface;
use App\Models\Setting;
use Illuminate\Support\Facades\Http;

class SSOService implements SSOServiceInterface
{

    protected $setting;

    public function __construct()
    {
        $this->setting = Setting::first();
    }

    /****  Log in a user *********************************************/

    public function login($username, $password, $deviceSecret)
    {

        $data["username"] = $username;
        $data["password"] = $password;
        $data["appSlug"] = $this->setting->app_slug;
        $data["deviceSecret"] = $deviceSecret;

        $url = $this->setting->api_sso_url . "auth/token";

        return json_decode(
            Http::withHeaders([
                'Accept' => 'application/json',
                'Content-Type' => "application/json"
            ])->post($url, $data), true
        );
    }

    /****  Disconnect a user *********************************************/
    public function logout($accessToken)
    {
        $url = $this->setting->api_sso_url . "user-logout";

        return json_decode(
            Http::withHeaders([
                'Accept' => 'application/json',
                "Authorization" => "Bearer $accessToken",
                'Content-Type' => "application/json"
            ])->get($url),true
        );
    }

    /****  Get Logged user details *********************************************/
    public function userDetail($accessToken)
    {
        $appSlug = $this->setting->app_slug;
        $url = $this->setting->api_sso_url."user-detail/" . $appSlug;

        return json_decode(
            Http::withHeaders([
                'Accept' => 'application/json',
                "Authorization" => "Bearer $accessToken",
                'Content-Type' => "application/json"
            ])->get($url),true
        );
    }

   /****  Find user by Id *********************************************/
    public function findById($userId, $accessToken)
    {
        $url = $this->setting->api_sso_url."user-info/".$userId;

        return json_decode(
            Http::withHeaders([
                'Accept' => 'application/json',
                "Authorization" => "Bearer $accessToken",
                'Content-Type' => "application/json"
            ])->get($url),true
        );
    }


    /****  List all users in application *********************************************/
    public function users($orgId, $pageNo, $pageSize, $accessToken)
    {
        $appId = $this->setting->application_id;
        $url = $this->setting->api_sso_url."users-in-app/" . $orgId . "/"  . $appId . "?pageNo=" . $pageNo . "&pageSize=" .$pageSize;

        return json_decode(
            Http::withHeaders([
                'Accept' => 'application/json',
                "Authorization" => "Bearer $accessToken",
                'Content-Type' => "application/json"
            ])->get($url),true
        );
    }

    /****  Delete application to the user *********************************************/
    public function deleteAppToUser($orgId, $userId, $accessToken)
    {
        $appId = $this->setting->application_id;
        $url = $this->setting->api_sso_url."user-app-delete/" . $orgId . "/" . $userId . "/" . $appId;

        return json_decode(
            Http::withHeaders([
                'Accept' => 'application/json',
                "Authorization" => "Bearer $accessToken",
                'Content-Type' => "application/json"
            ])->delete($url),true
        );
    }

}
