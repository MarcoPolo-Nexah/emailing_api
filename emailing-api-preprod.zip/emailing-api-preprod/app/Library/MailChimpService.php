<?php
/**
 * Created by PhpStorm.
 * User: eddy
 * Date: 13/12/18
 * Time: 10:47
 */

namespace App\Library;

use App\Library\Repository\MailServiceInterface;
use App\Models\Setting;
use MailchimpTransactional\ApiClient;

class MailChimpService implements MailServiceInterface
{

    protected $setting;
    protected $mailchimp;

    public function __construct()
    {
        $this->setting = Setting::first();
        $this->mailchimp = new ApiClient();
        $this->mailchimp->setApiKey($this->setting->mailchimp_api_key);
    }


    //---------------              Template APIs    -------------------------------//
    public function listTemplates()
    {
        return $this->mailchimp->templates->list();
    }

    public function renderTemplate($name)
    {
        return $response = $this->mailchimp->templates->render([
            "template_name" => $name,
            "template_content" => [["name" => "name", "content" => "content"]],
        ]);
    }

    public function deleteTemplate($name)
    {
        return $this->mailchimp->templates->delete(["name" => $name]);
    }

    public function addTemplate($name, $code, $publish = true)
    {
        return $this->mailchimp->templates->add(["name" => $name, "code" => $code, "publish" => $publish]);
    }

    public function updateTemplate($name, $code, $publish = true)
    {
        return $this->mailchimp->templates->update(["name" => $name, "code" => $code, "publish" => $publish]);
    }

    public function publishTemplate($name)
    {
        return $this->mailchimp->templates->publish(["name" => $name]);
    }

    public function infoTemplate($name)
    {
        return $this->mailchimp->templates->info(["name" => $name]);
    }
    //---------------              Template APIs    -------------------------------//

    //---------------              Message APIs    -------------------------------//
    public function infoMessage($id)
    {
        return $this->mailchimp->messages->info(["id" => $id]);
    }

    public function sendTemplateMsg($templateName, $to, $subject, $fromEmail, $fromName)
    {
        return $this->mailchimp->messages->sendTemplate([
            "template_name" => $templateName,
            "template_content" => [["name" => "", "content" => ""]],
            "message" => [
                "subject" => $subject,
                "from_email" => $fromEmail,
                "from_name" => $fromName,
                "to" => $to,
                //"merge_vars" => $mergeVars,
                "important" => "",
                "bcc_address" => "",
                "track_opens" => true,
                "track_clicks" => true,
            ],
        ]);

    }
    //---------------              Message APIs    -------------------------------//

}
