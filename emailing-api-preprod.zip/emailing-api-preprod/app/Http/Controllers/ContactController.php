<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Laravel\Lumen\Routing\Controller as BaseController;

class ContactController extends BaseController
{
    public function json($errcode, $message, $data = null)
    {
        return response()->json(array('errcode' => $errcode, 'message' => $message, 'data' => $data), $errcode);
    }

    public function create(Request $request)
    {
        try {
            $this->validate($request, [
                'name' => 'required|string|max:255',
                'status' => 'required|string|max:255',
                'schedule_time' => 'required|date',
                'object' => 'required|string|max:255',
                'nb_contact' => 'required|integer',
                'sent' => 'required|boolean',
                'failed' => 'required|boolean',
                'model_id' => 'required|integer',
                'group_id' => 'required|integer',
                'sso_user_id' => 'required|integer',
                'org_id' => 'required|integer',
            ]);

            $name = $request->input('name');
            $status = $request->input('status');
            $scheduleTime = $request->input('schedule_time');
            $object = $request->input('object');
            $nbContact = $request->input('nb_contact');
            $sent = $request->input('sent');
            $failed = $request->input('failed');
            $modelId = $request->input('model_id');
            $groupId = $request->input('group_id');
            $ssoUserId = $request->input('sso_user_id');
            $orgId = $request->input('org_id');

            $result = DB::select('CALL sp_campaign_create(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', [
                $name, $status, $scheduleTime, $object, $nbContact, $sent, $failed, $modelId, $groupId, $ssoUserId, $orgId
            ]);

            if (count($result) > 0) {
                return response()->json($result[0], Response::HTTP_CREATED);
            } else {
                return response()->json(['error' => 'Failed to create campaign'], Response::HTTP_INTERNAL_SERVER_ERROR);
            }
        } catch (ValidationException $e) {
            return response()->json(['error' => $e->getMessage()], Response::HTTP_BAD_REQUEST);
        } catch (\Exception $e) {
            return response()->json(['error' => 'An unexpected error occurred'], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function list(Request $request)
    {
        $paginate = $request->get('paginate', 1);
        $page = $request->get('page', 1);
        $perPage = $request->get('perPage', 20);

        $result = DB::select('call sp_campaign_list(?,?,?,?)', array($page, $perPage, $paginate));
        $total = DB::select('call sp_campaign_list(?,?,?,?)', array($page, $perPage, 0));

        $data = [
            'data' => $result,
            'per_page' => $perPage,
            'from' => ($page - 1) * $perPage + 1,
            'to' => ($page - 1) * $perPage + count($result),
            'total' => count($total),
        ];

        return response()->json($data, 200);

    }


    public function update(Request $request)
    {
        $idCampaign = $request->input('id_campaign');
        $name = $request->input('name');
        $status = $request->input('status');
        $scheduleTime = $request->input('schedule_time');
        $object = $request->input('object');
        $nbContact = $request->input('nb_contact');
        $sent = $request->input('sent');
        $failed = $request->input('failed');
        $modelId = $request->input('model_id');
        $groupId = $request->input('group_id');
        $ssoUserId = $request->input('sso_user_id');
        $orgId = $request->input('org_id');

        try {
            DB::select('CALL sp_campaign_update(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', [
                $idCampaign, $name, $status, $scheduleTime, $object, $nbContact, $sent, $failed, $modelId,
                $groupId, $ssoUserId, $orgId
            ]);

            return response()->json([
                'status' => 'success',
                'message' => 'Campaign updated successfully',
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Failed to update campaign',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

}
