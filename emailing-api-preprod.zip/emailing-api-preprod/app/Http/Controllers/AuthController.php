<?php


namespace App\Http\Controllers\Api;


use App\Library\SSOService;
use App\Utils\JResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Laravel\Lumen\Routing\Controller as BaseController;

class AuthController extends BaseController
{
    use JResponse;

    protected $ssoService;


    public function __construct()
    {
        $this->ssoService = new SSOService();
    }

    public function login(Request $request)
    {
        try {

            $this->validate($request, [
                'username' => 'required|string|max:255',
                'password' => 'required|string|max:255',
                'deviceSecret' => 'required|string|max:255'
            ]);
            $username = $request->input('name');
            $password = $request->input('name');
            $deviceSecret = $request->input('name');

            $response = $this->ssoService->login($username, $password, $deviceSecret);
            return $response;

        } catch (\Exception $e) {
           return $this->json("Error", $e->getMessage());
        }

    }

    public function logout()
    {
        $user = Auth::user();
        $response = $this->ssoService->logout($user->access_token);
        return $response;
    }

    public function userDetail()
    {
        $user = Auth::user();
        $response = $this->ssoService->userDetail($user->access_token);
        return $response;

    }

    public function findById(Request $request)
    {
        $user = Auth::user();
        $userId = $request->input("user_id");
        $response = $this->ssoService->findById($userId, $user->access_token);
        return $response;
    }


    public function users(Request $request)
    {
        $user = Auth::user();
        $pageNo = $request->input("pageNo");
        $pageSize = $request->input("pageSize");
        $response = $this->ssoService->users($user->org_id, $pageNo, $pageSize, $user->access_token);
        return $response;
    }

}
