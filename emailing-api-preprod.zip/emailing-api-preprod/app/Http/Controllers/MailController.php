<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Laravel\Lumen\Routing\Controller as BaseController;

class MailController extends BaseController
{
    public function json($errcode, $message, $data = null)
    {
        return response()->json(array('errcode' => $errcode, 'message' => $message, 'data' => $data), $errcode);
    }

    use Illuminate\Http\Response;
    use Illuminate\Validation\ValidationException;

    public function create(Request $request)
    {
        //
    }


    public function list(Request $request)
    {
        $paginate = $request->get('paginate', 1);
        $page = $request->get('page', 1);
        $perPage = $request->get('perPage', 20);

        $result = DB::select('CALL sp_mail_list(?, ?, ?, ?)', [$page, $perPage, $paginate]);
        $total = DB::select('CALL sp_mail_list(?, ?, ?, ?)', [$page, $perPage, 0]);

        $data = [
            'data' => $result,
            'per_page' => $perPage,
            'from' => ($page - 1) * $perPage + 1,
            'to' => ($page - 1) * $perPage + count($result),
            'total' => count($total),
        ];

        return response()->json($data, 200);
    }



    public function update(Request $request)
    {
        //

    }

}
