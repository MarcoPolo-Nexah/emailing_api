<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Laravel\Lumen\Routing\Controller as BaseController;
use App\Http\Controllers\Controller;

class GroupController extends BaseController
{
    public function json($errcode, $message, $data = null)
    {
        return response()->json(array('errcode' => $errcode, 'message' => $message, 'data' => $data), $errcode);
    }

    use Illuminate\Http\Response;
    use Illuminate\Validation\ValidationException;

    public function create(Request $request)
    {
        $name = $request->input('name');
        $nbContactList = $request->input('nb_contact');

        $nbContact = count($nbContactList);

        try {
            $result = DB::select('CALL sp_group_create(?, ?)', [$name, $nbContact]);

            if (count($result) > 0) {
                $groupResult = DB::select('SELECT * FROM groups WHERE id = LAST_INSERT_ID()');

                if (count($groupResult) > 0) {
                    $group = $groupResult[0];
                    $group->nb_contact = $nbContact;

                    return response()->json($group, 201);
                } else {
                    return response()->json(['error' => 'Failed to create group'], 500);
                }
            } else {
                return response()->json(['error' => 'Failed to create group'], 500);
            }
        } catch (\Exception $e) {
            return response()->json(['error' => 'An unexpected error occurred'], 500);
        }
    }

    public function createContactGroup(Request $request)
    {
        // Valider les données de la requête
        $this->validate($request, [
            'contact_id' => 'required|integer',
            'group_ids' => 'required|array',
            'group_ids.*' => 'integer',
        ]);

        $contactId = $request->input('contact_id');
        $groupIds = $request->input('group_ids');

        $results = [];

        try {
            foreach ($groupIds as $groupId) {
                // Appeler la procédure stockée sp_contact_group_create
                $result = DB::select('CALL sp_contact_group_create(?, ?)', [$contactId, $groupId]);

                if (count($result) > 0) {
                    $results[] = $result[0];
                }
            }

            return response()->json($results, 200);
        } catch (\Exception $e) {
            return response()->json(['error' => 'An unexpected error occurred'], 500);
        }
    }



    public function list(Request $request)
    {
        $paginate = $request->get('paginate', 1);
        $page = $request->get('page', 1);
        $perPage = $request->get('perPage', 20);
        $result = DB::select('CALL sp_group_list(?, ?, ?, ?)', [$page, $perPage, $paginate]);
        $total = DB::select('CALL sp_group_list(?, ?, ?, ?)', [$page, $perPage, 0]);

        $data = [
            'data' => $result,
            'per_page' => $perPage,
            'from' => ($page - 1) * $perPage + 1,
            'to' => (($page - 1) * $perPage) + count($result),
            'total' => count($total),
        ];

        return response()->json($data, 200);
    }


    public function update(Request $request)
    {
        $idContact = $request->get('id_contact');
        $name = $request->get('name');
        $phoneNumber = $request->get('phone_number');
        $email = $request->get('email');
        $ssoUserId = $request->get('sso_user_id');
        $orgId = $request->get('org_id');

        try {
            $result = DB::select('CALL sp_contact_update(?, ?, ?, ?, ?, ?)', [
                $idContact,
                $name,
                $phoneNumber,
                $email,
                $ssoUserId,
                $orgId
            ]);

            return response()->json(['message' => 'Contact updated successfully'], 200);
        } catch (\Exception $e) {
            return response()->json(['error' => 'An unexpected error occurred'], 500);
        }
    }

}


