<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Laravel\Lumen\Routing\Controller as BaseController;

class ModelController extends BaseController
{
    public function json($errcode, $message, $data = null)
    {
        return response()->json(array('errcode' => $errcode, 'message' => $message, 'data' => $data), $errcode);
    }


    public function create(Request $request)
    {
        try {
            $this->validate($request, [
                'name' => 'required|string|max:255',
                'description' => 'required|string|max:255',
                'sso_user_id' => 'required|integer',
                'org_id' => 'required|integer',
            ]);

            $user = Auth::user();
            $name = $request->get('name');
            $description = $request->get('description');
            $ssoUserId = $user->sso_user_id;
            $orgId = $user->org_id;

            $result = DB::select('CALL sp_model_create(?, ?, ?, ?)', [
                $name, $description, $ssoUserId, $orgId
            ]);

            if (count($result) > 0) {
                return response()->json($result[0], 201);
            } else {
                return response()->json(['error' => 'Failed to create model'], 500);
            }
        } catch (ValidationException $e) {
            return response()->json(['error' => $e->getMessage()], 400);
        } catch (\Exception $e) {
            return response()->json(['error' => 'An unexpected error occurred'], 500);
        }
    }


    public function list(Request $request)
    {
        $paginate = $request->get('paginate', 1);
        $page = $request->get('page', 1);
        $perPage = $request->get('perPage', 20);

        $result = DB::select('call sp_model_list(?,?,?,?)', array($page, $perPage, $paginate));
        $total = DB::select('call sp_model_list(?,?,?,?)', array($page, $perPage, 0));

        $data = [
            'data' => $result,
            'per_page' => $perPage,
            'from' => ($page - 1) * $perPage + 1,
            'to' => ($page - 1) * $perPage + count($result),
            'total' => count($total),
        ];

        return response()->json($data, 200);
    }


    public function update(Request $request)
    {
        try {
            $this->validate($request, [
                'id_model' => 'required|integer',
                'name' => 'required|string|max:255',
                'description' => 'required|string|max:255',
                'sso_user_id' => 'required|integer',
                'org_id' => 'required|integer',
            ]);

            $user = Auth::user();
            $idModel = $request->input('id_model');
            $name = $request->input('name');
            $description = $request->input('description');
            $ssoUserId = $user->sso_user_id;
            $orgId = $user->org_id;

            DB::select('CALL sp_model_update(?, ?, ?, ?, ?)', [
                $idModel, $name, $description, $ssoUserId, $orgId
            ]);

            return response()->json([
                'status' => 'success',
                'message' => 'Model updated successfully',
            ], 200);
        } catch (ValidationException $e) {
            return response()->json(['error' => $e->getMessage()], 400);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Failed to update model'], 500);
        }
    }

}
