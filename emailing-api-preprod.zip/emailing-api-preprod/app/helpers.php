<?php

/*
 * Global helpers file with misc functions.
 */

use App\Models\Credentials;
use App\Models\Crypto;
use App\Models\Setting;
use Illuminate\Contracts\Container\BindingResolutionException;
use Illuminate\Contracts\Validation\Factory;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Collection;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

if (!function_exists('response_msg_translate')) {
    /**
     * Helper to grab the application name.
     *
     * @param $fr
     * @param $en
     * @return mixed
     */
    function response_msg_translate($fr, $en)
    {
        return array(
            'fr' => $fr,
            'en' => $en
        );
    }
}
if (!function_exists('short_message')) {
    /**
     * Helper to grab the application name.
     *
     * @param array $array_key
     * @param array $array_values
     * @param $message
     * @param $task_name
     * @return mixed
     */
    function short_message(array $array_key, array $array_values, $message, $task_name = null)
    {
        $message_original = str_replace($array_key, $array_values, $message);
        $msg_length = 160 - strlen($message_original);
        if ($task_name) {
            $short_task_name = cut_string($task_name, $msg_length);
            $array_values[count($array_values) - 1] = $short_task_name;
        }
        return str_replace($array_key, $array_values, $message);
    }
}

if (!function_exists('cut_string')) {
    /**
     * Helper to grab the application name.
     *
     * @param $text
     * @param $max
     * @return mixed
     */
    function cut_string($text, $max)
    {
        if (strlen($text) <= $max)
            return $text;
        return substr($text, 0, $max - 3) . '...';
    }
}

if (!function_exists('crypter')) {

    /** Crypter un texte
     * @param $plainText
     * @return string
     */

    function crypter($plainText)
    {
        $crypto = new Crypto();
        $key = Setting::first()->crypto_key;
        $iv = "Y8g0mBXjtLw4ZOUW";
        $cipherText = $crypto->encrypt($key, $iv, $plainText);
        return $cipherText;
    }

}

if (!function_exists('decrypter')) {

    /** Décrypter un texte
     * @param $cipherText
     * @return string
     */
    function decrypter($cipherText)
    {
        $crypto = new Crypto();
        $key = Setting::first()->crypto_key;
        $plainText = $crypto->decrypt($key, $cipherText);
        return $plainText;
    }

}


if (!function_exists('generate_target')) {

    /** Générer une cible unique
     * @param $id
     * @param int $nbre
     * @return string
     */
    function generate_target($id, $nbre = 2)
    {
        $str = Str::random($nbre);
        return str_replace('-', '', str_shuffle($id . $str));
    }

}


if (!function_exists('validateWith')) {

    /** Générer une cible unique
     * @param $validator
     * @param Request|null $request
     * @return array|Exception|ValidationException
     */
    function validateWith($validator, Request $request = null)
    {
        try {
            $request = $request ?: request();
            if (is_array($validator)) {
                $validator = getValidationFactory()->make($request->all(), $validator);
            }
            return $validator->validate();
        } catch (ValidationException $e) {
            return $e;
        }
    }

    /**
     * Get a validation factory instance.
     *
     * @return Factory
     */
    function getValidationFactory()
    {
        return app(Factory::class);
    }
}


if (!function_exists('credentials')) {
    /**
     * Get a an encrypted value.
     *
     * @param string $key
     * @param null $default
     * @return mixed
     */
    function credentials($key, $default = null)
    {
        $filename = app()->basePath('config') . ('credentials.php.enc' ? DIRECTORY_SEPARATOR . 'credentials.php.enc' : 'credentials.php.enc');
        try {
            $credentials = app(Credentials::class);
            $credentials->load($filename);
            return $credentials->get($key, $default);
        } catch (ReflectionException | BindingResolutionException $e) {
            return Credentials::CONFIG_PREFIX . $key;
        }

    }
}


if (!function_exists('public_path')) {
    /**
     * Get the path to the public folder.
     *
     * @param string $path
     * @return string
     */
    function public_path($path = '')
    {
        return env('PUBLIC_PATH', base_path('storage/app')) . ($path ? '/' . $path : $path);
    }
}

if (!function_exists('date_to_utc')) {
    /**
     * Get the path to the public folder.
     *
     * @param string $date
     * @return mixed
     */
    function date_to_utc($date)
    {
        return date("Y-m-d H:i:s", strtotime('-1 hour', strtotime($date)));
    }
}


if (!function_exists('paginate_array')) {

    /** Paginer un tableau
     * @param $items
     * @param int $perPage
     * @param null $page
     * @param array $options
     * @return mixed
     */
    function paginate_array($items, $perPage = 10, $page = null, $options = [])
    {
        $page = $page ?: (Paginator::resolveCurrentPage() ?: 1);
        $items = $items instanceof Collection ? $items : Collection::make($items);
        return new LengthAwarePaginator($items->forPage($page, $perPage), $items->count(), $perPage, $page, $options);
    }
}
