<?php

namespace App\Console\Commands;

use App\Library\MailChimpService;
use Illuminate\Console\Command;
use MailchimpTransactional\ApiClient;

class TestCommand extends Command
{
    /**
     * The console command name.
     *
     * @var string
     */
    protected $signature = 'test:do';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'do test';


    public function handle()
    {


    }
}
