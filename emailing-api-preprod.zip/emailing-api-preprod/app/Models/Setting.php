<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Setting extends Model
{

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'settings';

    /**
     * The database primary key value.
     *
     * @var string
     */
    protected $primaryKey = 'id';

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */

    protected $fillable = [
        'id',
        'application_id',
        'app_slug',
        'app_secret',
        'mailchimp_api_key',
        'sms_token',
        'crypto_key',
        'app_web_url',
        'api_sms_url',
        'api_sso_url',
        'api_org_url',
        'api_shortener_url'
    ];

}
